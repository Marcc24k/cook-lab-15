(function(){
var app = angular.module("phrasenator", ["ngRoute"]);

app.config(function($routeProvider){
    $routeProvider.when("/form",{
        templateUrl: "partials/form.html",
        controller: "formController"
    });
    $routeProvider.when("/phrase",{
        templateUrl: "partials/phrase.html"
    });
});

app.controller("formController",function($scope, wordStore){
    $scope.submitForm = function(){
        console.log("Noun:", $scope.words.noun);
        console.log("Adjective:", $scope.words.adjective);

        wordStore.setWords($scope.words);
    };
    $scope.words = {};
    window.wordStore = wordStore;
});

app.factory("wordStore", function (){
    var storedWords = {};
    function setWords (words) {
        console.log("setWords ", words);
        storedWords = words;
    }
    function getWords () {
        console.log("getWords ", storedWords);
        return storedWords;
    }

    return {
        setWords: setWords,
        getWords: getWords
    }
    // Or we could do this...
    // var service = {};
    // service.setWords = setWords;
    // service.getWords = getWords;
    // return service;
});

})();
